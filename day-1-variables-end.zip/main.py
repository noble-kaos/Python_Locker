name = "Jack"
print(name)

name = "Angela"
print(name)


name = input("What is your name?")
length = len(name)
print(length)