# 🚨 Don't change the code below 👇
two_digit_number = input("Type a two digit number: ")
# 🚨 Don't change the code above 👆

####################################
#Write your code below this line 👇
"""
print(type(two_digit_number))
dig1 = int(two_digit_number[0])
dig2 = int(two_digit_number[1])
print(dig1 + dig2)

"""


"""
a = str(two_digit_number)
print(type(a))
print(int(a[0]) + int(a[1]))

"""





