#Data Types
print("Hello"[0])
