name = input("What is your name?")
print(name)

name = "cara"
print(name)

name = input("what is your name")
length = len(name)
print(length)

