print("Welcome to the rollercoaster!")
height = int(input("What is your height in cm? "))
if height >= 120:
  print("You can ride this rollercoaster")
else:
  print("Sorry you need to grow a bit")
