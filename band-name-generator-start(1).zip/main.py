#1. Create a greeting for your program.
print("This is the band name generator, Welcome.")

#2. Ask the user for the city that they grew up in.
city = input("which city do you tell people you are from ? \n")

#3. Ask the user for the name of a pet.
pet = input("What is the name of your favorite pet of all time ? \n")
#4. Combine the name of their city and pet and show them their band name.
print("your band name could be " + city + " " + pet)
#5. Make sure the input cursor shows on a new line, see the example at:
#   https://band-name-generator-end.appbrewery.repl.run/