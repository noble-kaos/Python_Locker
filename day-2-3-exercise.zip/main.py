# 🚨 Don't change the code below 👇
age = input("What is your current age?")
# 🚨 Don't change the code above 👆

#Write your code below this line 👇

age_int = int(age)

yr_remaining = 90 - age_int
days_remaining = yr_remaining * 365
wks_remaining = yr_remaining * 52
months_remaining = yr_remaining * 12

print(f"If you were to die at 90 years of age; This is how long you have in...\n years: {yr_remaining}, \ndays:{days_remaining}, \nweeks: {wks_remaining}, \nmonths:{months_remaining}")







